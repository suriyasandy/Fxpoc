import pandas as pd
import numpy as np
from arch import arch_model
from scipy.stats import genpareto

SQRT252 = np.sqrt(252)

def compute_manual_group_thresholds(df):
    df['DailyVol'] = df['OHLCVolatility'] / SQRT252
    mean_vol = df.groupby('Currency')['DailyVol'].mean().reset_index(name='MeanVol')
    
    bins = [0, 0.07, 0.50, 0.60, float('inf')]
    labels = ['Low', 'Medium', 'High', 'Very High']
    mean_vol['Group'] = pd.cut(mean_vol['MeanVol'], bins=bins, labels=labels)
    
    group_thresholds = mean_vol.groupby('Group')['MeanVol'].max().reset_index(name='ManualThreshold')
    return mean_vol, group_thresholds

def build_cross_rates(df):
    pivot_close = df.pivot(index='Date', columns='Currency', values='Close')
    pivot_vol = df.pivot(index='Date', columns='Currency', values='OHLCVolatility') / SQRT252
    crosses = []
    currencies = sorted(df['Currency'].unique())

    for i in range(len(currencies)):
        for j in range(len(currencies)):
            if i != j:
                base, quote = currencies[i], currencies[j]
                cross_name = f"{base}/{quote}"
                try:
                    rate = pivot_close[base] / pivot_close[quote]
                    vol = np.sqrt(pivot_vol[base] ** 2 + pivot_vol[quote] ** 2)
                    lr = np.log(rate / rate.shift(1))
                    temp = pd.DataFrame({
                        'Date': rate.index,
                        'Cross': cross_name,
                        'Rate': rate.values,
                        'CrossVol': vol.values,
                        'LogReturn': lr.values
                    }).dropna()
                    crosses.append(temp)
                except:
                    continue
    return pd.concat(crosses, ignore_index=True)

def rolling_quantile(series, window, q):
    return series.rolling(window=window, min_periods=1).quantile(q)

def garch_evt(log_returns, tail_pct=0.99):
    am = arch_model(log_returns.dropna()*100, vol='Garch', p=1, q=1)
    res = am.fit(disp='off')
    std = res.resid / res.conditional_volatility
    std = std.dropna()
    threshold = np.quantile(std, 0.90)
    excess = std[std > threshold] - threshold
    c, loc, scale = genpareto.fit(excess, floc=0)
    p_exc = (tail_pct - (1 - (std > threshold).mean())) / (std > threshold).mean()
    var_evt = genpareto.ppf(p_exc, c, loc=0, scale=scale)
    return (threshold + var_evt) / 100